# model.py
import joblib
import pandas as pd
from recommendation_model import RecommendationModel  # Import from existing file

def load_sarima_model(model_path='model\\sarima_model.pkl'):
    """Load the trained SARIMA model from a .pkl file."""
    try:
        model = joblib.load(model_path)
        print(f"✅ SARIMA model loaded from {model_path}")
        return model
    except FileNotFoundError:
        raise Exception(f"Model file {model_path} not found.")
    except Exception as e:
        raise Exception(f"Error loading SARIMA model: {str(e)}")

def predict_sarima(model, start_date, end_date):
    """Generate predictions using the loaded SARIMA model."""
    try:
        last_date = pd.to_datetime(start_date)
        end_date = pd.to_datetime(end_date)
        months_to_predict = (end_date.year - last_date.year) * 12 + (end_date.month - last_date.month)
        forecast_dates = pd.date_range(start=last_date + pd.DateOffset(months=1), periods=months_to_predict, freq='MS')

        # Generate predictions
        forecast_result = model.get_forecast(steps=months_to_predict)
        forecast = forecast_result.predicted_mean.clip(lower=0)
        conf_int = forecast_result.conf_int().clip(lower=0)

        # Create result DataFrame
        result_df = pd.DataFrame({
            'Date': forecast_dates,
            'Prévision': forecast.values,
            'Borne Inf': conf_int.iloc[:, 0].values,
            'Borne Sup': conf_int.iloc[:, 1].values
        })
        return result_df
    except Exception as e:
        raise Exception(f"Error generating SARIMA predictions: {str(e)}")

def load_admission_model(model_path='model\\admission_model.pkl'):
    """Load the admission model."""
    try:
        model = joblib.load(model_path)
        print(f"✅ Admission model loaded from {model_path}")
        return model
    except FileNotFoundError:
        raise Exception(f"Model file {model_path} not found.")
    except Exception as e:
        raise Exception(f"Error loading admission model: {str(e)}")