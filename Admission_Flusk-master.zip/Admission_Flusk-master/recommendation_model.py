import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler, LabelEncoder
from tensorflow.keras.models import load_model

class RecommendationModel:
    def __init__(self, model_path, data_path):
        """
        Initialize the recommendation model by loading the model and fitting preprocessors.
        
        Args:
            model_path (str): Path to the saved TensorFlow model (.h5 file).
            data_path (str): Path to the training data CSV for fitting preprocessors.
        """
        print("Starting model initialization...")
        # Load the model
        print(f"Attempting to load model from: {model_path}")
        self.model = load_model(model_path)
        print("Model loaded successfully.")

        # Initialize preprocessors
        self.scaler = MinMaxScaler()
        self.label_encoder = LabelEncoder()
        
        # Load training data to fit preprocessors
        print(f"Loading training data from: {data_path}")
        try:
            df = pd.read_csv(data_path)
            print("Data loaded successfully. Shape:", df.shape)
            print("Training data types:", df.dtypes.to_dict())
        except Exception as e:
            print(f"Failed to load CSV: {str(e)}")
            raise

        features = ['Note_Maths', 'Note_Physique', 'Note_Info', 'Score_Anglais', 'Bac_Type', 'Activite_Extra', 'Interet_IA']
        print("Selected features:", features)
        X = df[features]
        try:
            X = pd.get_dummies(X, columns=['Bac_Type', 'Activite_Extra'])
            # Convert all one-hot encoded columns to int64
            for col in X.columns:
                if X[col].dtype == bool:
                    X[col] = X[col].astype('int64')
            print("Data after one-hot encoding. Shape:", X.shape)
            print("Feature columns:", X.columns.tolist())
            print("Feature column types:", X.dtypes.to_dict())
        except Exception as e:
            print(f"Error in one-hot encoding: {str(e)}")
            raise
        
        # Fit the scaler on numeric features
        print("Fitting scaler on numeric features...")
        try:
            X[['Note_Maths', 'Note_Physique', 'Note_Info', 'Score_Anglais']] = X[
                ['Note_Maths', 'Note_Physique', 'Note_Info', 'Score_Anglais']
            ].astype(float)
            print("Training numeric columns types:", X[['Note_Maths', 'Note_Physique', 'Note_Info', 'Score_Anglais']].dtypes.to_dict())
            self.scaler.fit(X[['Note_Maths', 'Note_Physique', 'Note_Info', 'Score_Anglais']])
            print("Scaler fitted.")
        except Exception as e:
            print(f"Error fitting scaler: {str(e)}")
            raise

        # Fit the label encoder on target classes
        print("Fitting label encoder on target classes...")
        self.label_encoder.fit(['Informatique', 'IA', 'Electromecanique', 'Telecom'])
        print("Label encoder fitted.")

        # Store feature columns for alignment
        self.feature_columns = X.columns
        print("Feature columns stored. Total columns:", len(self.feature_columns))
        print("Model initialization completed.")

    def preprocess(self, input_data):
        """
        Preprocess input data to match the training format.
        
        Args:
            input_data (dict): Dictionary containing input features.
            
        Returns:
            np.ndarray: Preprocessed input ready for prediction.
        """
        print("Starting preprocessing for input data...")
        print("Input data:", input_data)
        
        # Convert input to DataFrame
        try:
            new_student = pd.DataFrame([input_data])
            print("Converted to DataFrame. Shape:", new_student.shape)
            print("Initial data types:", new_student.dtypes.to_dict())
        except Exception as e:
            print(f"Error creating DataFrame: {str(e)}")
            raise

        # Ensure numeric columns are float
        numeric_cols = ['Note_Maths', 'Note_Physique', 'Note_Info', 'Score_Anglais']
        try:
            for col in numeric_cols:
                new_student[col] = pd.to_numeric(new_student[col], errors='raise')
            print("Numeric columns types after conversion:", new_student[numeric_cols].dtypes.to_dict())
            print("Numeric columns values:", new_student[numeric_cols].to_dict())
        except Exception as e:
            print(f"Error converting numeric columns: {str(e)}")
            raise

        # Apply one-hot encoding
        try:
            new_student = pd.get_dummies(new_student, columns=['Bac_Type', 'Activite_Extra'])
            # Convert all one-hot encoded columns to int64
            for col in new_student.columns:
                if new_student[col].dtype == bool:
                    new_student[col] = new_student[col].astype('int64')
            print("After one-hot encoding. Shape:", new_student.shape)
            print("Columns after encoding:", new_student.columns.tolist())
            print("Data types after encoding:", new_student.dtypes.to_dict())
            print("Numeric columns values after encoding:", new_student[numeric_cols].to_dict())
        except Exception as e:
            print(f"Error in one-hot encoding: {str(e)}")
            raise
        
        # Add missing columns and align with training data
        for col in self.feature_columns:
            if col not in new_student.columns:
                new_student[col] = 0
                print(f"Added missing column: {col}")
        new_student = new_student[self.feature_columns]
        print("After aligning columns. Shape:", new_student.shape)
        print("Aligned columns:", new_student.columns.tolist())
        print("Data types after alignment:", new_student.dtypes.to_dict())
        print("Numeric columns values after alignment:", new_student[numeric_cols].to_dict())
        
        # Scale numeric features
        print("Scaling numeric features...")
        try:
            for col in numeric_cols:
                if not pd.api.types.is_numeric_dtype(new_student[col]):
                    print(f"Non-numeric values in {col}:", new_student[col].values)
                    raise ValueError(f"Column {col} has non-numeric dtype: {new_student[col].dtype}")
            new_student[numeric_cols] = self.scaler.transform(new_student[numeric_cols].astype(float))
            print("Numeric features scaled.")
            print("Scaled numeric columns values:", new_student[numeric_cols].to_dict())
        except Exception as e:
            print(f"Error scaling features: {str(e)}")
            raise
        
        # Convert entire DataFrame to float64 for TensorFlow
        try:
            new_student = new_student.astype('float64')
            print("Converted all columns to float64. Data types:", new_student.dtypes.to_dict())
        except Exception as e:
            print(f"Error converting to float64: {str(e)}")
            raise
        
        # Convert to NumPy array and verify dtype
        try:
            result = new_student.values
            print("NumPy array dtype:", result.dtype)
            return result
        except Exception as e:
            print(f"Error converting to NumPy array: {str(e)}")
            raise

    def predict(self, input_data):
        """
        Make a prediction for the given input data.
        
        Args:
            input_data (dict): Dictionary containing input features.
            
        Returns:
            str: Predicted filiere (e.g., 'Informatique', 'IA', etc.).
        """
        print("Starting prediction process...")
        try:
            processed_data = self.preprocess(input_data)
            print("Preprocessed data shape:", processed_data.shape)
        except Exception as e:
            print(f"Error in preprocessing: {str(e)}")
            raise
        
        # Make prediction
        print("Making prediction...")
        try:
            # Ensure input is float32 for TensorFlow
            processed_data = processed_data.astype(np.float32)
            print("Processed data dtype for prediction:", processed_data.dtype)
            prediction = self.model.predict(processed_data)
            print("Prediction raw output:", prediction)
            predicted_class_index = np.argmax(prediction, axis=1)[0]
            print("Predicted class index:", predicted_class_index)
        except Exception as e:
            print(f"Error in prediction: {str(e)}")
            raise
        
        # Decode the prediction
        try:
            predicted_filiere = self.label_encoder.classes_[predicted_class_index]
            print(f"Predicted filiere: {predicted_filiere}")
            return predicted_filiere
        except Exception as e:
            print(f"Error decoding prediction: {str(e)}")
            raise