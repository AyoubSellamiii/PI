import os
import pandas as pd
import numpy as np
from flask import Flask, request, jsonify
from model import load_sarima_model, predict_sarima, load_admission_model, RecommendationModel

app = Flask(__name__)

# Log to confirm Flask app initialization
print("Flask app initialized. Registering routes...")

# Initialize the recommendation model
try:
    print("Attempting to initialize RecommendationModel...")
    rec_model = RecommendationModel(
        model_path='model\\model.h5',
        data_path='MOCK_DATA_FINAL_COMPLET.csv'
    )
    print("RecommendationModel initialized successfully.")
except Exception as e:
    print(f"Failed to initialize RecommendationModel: {str(e)}")
    raise

# Load the admission model
try:
    print("Attempting to load AdmissionModel...")
    admission_model = load_admission_model()
    print("AdmissionModel loaded successfully.")
except Exception as e:
    print(f"Failed to load AdmissionModel: {str(e)}")
    raise

# Load the SARIMA model
try:
    print("Attempting to initialize SARIMAModel...")
    sarima_model = load_sarima_model()
    print("SARIMAModel initialized successfully.")
except Exception as e:
    print(f"Failed to initialize SARIMAModel: {str(e)}")
    raise

@app.route('/')
def home():
    print("Root route accessed.")
    return jsonify({
        'message': 'Welcome to the Recommendation System API. Use /api/recommend for filiere predictions, /api/predict_admission for admission predictions, /api/recommend_admission for admission recommendations, or /api/predict_hiring for hiring forecasts.'
    }), 200

@app.route('/api/recommend', methods=['POST'])
def predict_recommendation():
    print("Recommend route accessed.")
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No input data provided'}), 400

        required_fields = ['Note_Maths', 'Note_Physique', 'Note_Info', 'Score_Anglais', 'Bac_Type', 'Activite_Extra', 'Interet_IA']
        missing_fields = [field for field in required_fields if field not in data]
        if missing_fields:
            return jsonify({'error': f'Missing fields: {", ".join(missing_fields)}'}), 400

        numeric_fields = ['Note_Maths', 'Note_Physique', 'Note_Info', 'Score_Anglais', 'Interet_IA']
        for field in numeric_fields:
            if not isinstance(data[field], (int, float)):
                return jsonify({'error': f'{field} must be a number'}), 400
            if field != 'Score_Anglais' and not 0 <= data[field] <= 20:
                return jsonify({'error': f'{field} must be between 0 and 20'}), 400
            if field == 'Score_Anglais' and not 0 <= data[field] <= 100:
                return jsonify({'error': 'Score_Anglais must be between 0 and 100'}), 400
            if field == 'Interet_IA' and data[field] not in [0, 1]:
                return jsonify({'error': 'Interet_IA must be 0 or 1'}), 400

        valid_bac_types = ['Scientifique', 'Technique', 'Economie', 'Lettres', 'Sciences']
        valid_activities = ['Aucune', 'Club Robotique', 'Club Sportif', 'Debat', 'Hackathon IA']
        if data['Bac_Type'] not in valid_bac_types:
            return jsonify({'error': f'Bac_Type must be one of: {", ".join(valid_bac_types)}'}), 400
        if data['Activite_Extra'] not in valid_activities:
            return jsonify({'error': f'Activite_Extra must be one of: {", ".join(valid_activities)}'}), 400

        input_data = {
            'Note_Maths': float(data['Note_Maths']),
            'Note_Physique': float(data['Note_Physique']),
            'Note_Info': float(data['Note_Info']),
            'Score_Anglais': float(data['Score_Anglais']),
            'Bac_Type': data['Bac_Type'],
            'Activite_Extra': data['Activite_Extra'],
            'Interet_IA': int(data['Interet_IA'])
        }

        print("Making prediction with input data:", input_data)
        prediction = rec_model.predict(input_data)
        print(f"Prediction result: {prediction}")
        return jsonify({'recommended_filiere': prediction}), 200

    except Exception as e:
        print(f"Error in predict_recommendation: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/predict_admission', methods=['POST'])
def predict_admission():
    print("Predict admission route accessed.")
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No input data provided'}), 400

        required_fields = ['moy_bac_et', 'score_final', 'Nature_diplome', 'sexe']
        missing_fields = [field for field in required_fields if field not in data]
        if missing_fields:
            return jsonify({'error': f'Missing fields: {", ".join(missing_fields)}'}), 400

        numeric_fields = ['moy_bac_et', 'score_final']
        for field in numeric_fields:
            if not isinstance(data[field], (int, float)):
                return jsonify({'error': f'{field} must be a number'}), 400
            if field == 'moy_bac_et' and not 0 <= data[field] <= 20:
                return jsonify({'error': 'moy_bac_et must be between 0 and 20'}), 400
            if field == 'score_final' and not 0 <= data[field] <= 100:
                return jsonify({'error': 'score_final must be between 0 and 100'}), 400

        valid_diplomas = ['BAC', 'INCONNU']
        valid_sexes = ['M', 'F', 'INCONNU']
        if data['Nature_diplome'].upper() not in valid_diplomas:
            return jsonify({'error': f'Nature_diplome must be one of: {", ".join(valid_diplomas)}'}), 400
        if data['sexe'].upper() not in valid_sexes:
            return jsonify({'error': f'sexe must be one of: {", ".join(valid_sexes)}'}), 400

        input_data = {
            'moy_bac_et': float(data['moy_bac_et']),
            'score_final': float(data['score_final']),
            'Nature_diplome': data['Nature_diplome'].upper(),
            'sexe': data['sexe'].upper()
        }

        input_data['interaction_moyenne_score'] = input_data['moy_bac_et'] * input_data['score_final']
        input_data['score_ratio'] = input_data['score_final'] / (input_data['moy_bac_et'] + 1e-3)
        input_data['diff_score'] = input_data['score_final'] - input_data['moy_bac_et']

        input_df = pd.DataFrame([input_data])

        print("Making admission prediction with input data:", input_data)
        prediction = admission_model.predict(input_df)[0]
        result = 'Admis' if prediction == 1 else 'Non Admis'
        print(f"Admission prediction result: {result}")

        return jsonify({'admission_result': result}), 200

    except Exception as e:
        print(f"Error in predict_admission: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/recommend_admission', methods=['POST'])
def recommend_admission():
    print("Recommend admission route accessed.")
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No input data provided'}), 400

        required_fields = ['moy_bac_et', 'score_final', 'Nature_diplome', 'sexe']
        missing_fields = [field for field in required_fields if field not in data]
        if missing_fields:
            return jsonify({'error': f'Missing fields: {", ".join(missing_fields)}'}), 400

        numeric_fields = ['moy_bac_et', 'score_final']
        for field in numeric_fields:
            if not isinstance(data[field], (int, float)):
                return jsonify({'error': f'{field} must be a number'}), 400
            if field == 'moy_bac_et' and not 0 <= data[field] <= 20:
                return jsonify({'error': 'moy_bac_et must be between 0 and 20'}), 400
            if field == 'score_final' and not 0 <= data[field] <= 100:
                return jsonify({'error': 'score_final must be between 0 and 100'}), 400

        valid_diplomas = ['BAC', 'INCONNU']
        valid_sexes = ['M', 'F', 'INCONNU']
        if data['Nature_diplome'].upper() not in valid_diplomas:
            return jsonify({'error': f'Nature_diplome must be one of: {", ".join(valid_diplomas)}'}), 400
        if data['sexe'].upper() not in valid_sexes:
            return jsonify({'error': f'sexe must be one of: {", ".join(valid_sexes)}'}), 400

        input_data = {
            'moy_bac_et': float(data['moy_bac_et']),
            'score_final': float(data['score_final']),
            'Nature_diplome': data['Nature_diplome'].upper(),
            'sexe': data['sexe'].upper()
        }

        input_data['interaction_moyenne_score'] = input_data['moy_bac_et'] * input_data['score_final']
        input_data['score_ratio'] = input_data['score_final'] / (input_data['moy_bac_et'] + 1e-3)
        input_data['diff_score'] = input_data['score_final'] - input_data['moy_bac_et']

        input_df = pd.DataFrame([input_data])

        print("Making admission prediction for recommendation with input data:", input_data)
        prediction = admission_model.predict(input_df)[0]
        admission_result = 'Admis' if prediction == 1 else 'Non Admis'
        print(f"Admission prediction for recommendation: {admission_result}")

        recommendation = {}
        if admission_result == 'Admis':
            if input_data['moy_bac_et'] >= 16 and input_data['score_final'] >= 60:
                recommendation['university_level'] = 'Top-tier university'
                recommendation['program'] = 'Engineering or Sciences'
                recommendation['advice'] = 'Your scores are excellent! Apply to competitive programs.'
            else:
                recommendation['university_level'] = 'Mid-tier university'
                recommendation['program'] = 'General Sciences or Technology'
                recommendation['advice'] = 'You qualify for admission. Consider programs that align with your strengths.'
        else:
            recommendation['university_level'] = 'Standard university or preparatory program'
            recommendation['program'] = 'Foundation or Preparatory Course'
            if input_data['score_final'] < 40:
                recommendation['advice'] = 'Consider improving your score_final (aim for above 50) to increase your chances.'
            else:
                recommendation['advice'] = 'Your scores are close. Retake the exam or apply to less competitive programs.'

        print(f"Admission recommendation: {recommendation}")
        return jsonify({
            'admission_result': admission_result,
            'recommendation': recommendation
        }), 200

    except Exception as e:
        print(f"Error in recommend_admission: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/predict_hiring', methods=['POST'])
def predict_hiring():
    print("Predict hiring route accessed.")
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No input data provided'}), 400

        required_fields = ['start_date', 'end_date']
        missing_fields = [field for field in required_fields if field not in data]
        if missing_fields:
            return jsonify({'error': f'Missing fields: {", ".join(missing_fields)}'}), 400

        try:
            start_date = pd.to_datetime(data['start_date'])
            end_date = pd.to_datetime(data['end_date'])
            if start_date >= end_date:
                return jsonify({'error': 'start_date must be before end_date'}), 400
        except ValueError:
            return jsonify({'error': 'Invalid date format. Use YYYY-MM-DD'}), 400

        print(f"Making hiring prediction from {data['start_date']} to {data['end_date']}")
        result_df = predict_sarima(sarima_model, data['start_date'], data['end_date'])

        result_json = result_df.to_dict(orient='records')

        return jsonify({
            'status': 'success',
            'predictions': result_json
        }), 200

    except Exception as e:
        print(f"Error in predict_hiring: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/health', methods=['GET'])
def health_check():
    print("Health route accessed.")
    return jsonify({'status': 'healthy'}), 200

if __name__ == '__main__':
    print("Starting Flask app...")
    app.run(debug=True, host='0.0.0.0', port=5001)