// hiring-predict.component.ts
import { Component, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { HiringService, HiringPrediction } from '../../services/hiring.service';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { CommonModule } from '@angular/common';
import { BaseChartDirective } from 'ng2-charts';
import { ChartData } from 'chart.js';
import { UserService } from '../../services/user.service';

@Component({
    selector: 'app-hiring-predict',
    standalone: true,
    imports: [
        CommonModule,
        MatCardModule,
        MatFormFieldModule,
        MatInputModule,
        MatButtonModule,
        ReactiveFormsModule,
        BaseChartDirective
    ],
    templateUrl: './hiring-predict.component.html'
})
export class HiringPredictComponent {
    hiringForm: FormGroup;
    predictions: HiringPrediction[] = [];
    error: string | null = null;
    role: string | null = null;

    chartData: ChartData<'line'> = {
        labels: [],
        datasets: []
    };

    chartOptions = {
        responsive: true
    };

    @ViewChild(BaseChartDirective) chart?: BaseChartDirective;

    constructor(
        private fb: FormBuilder,
        private hiringService: HiringService,
        private userService: UserService
    ) {
        this.hiringForm = this.fb.group({
            start_date: ['', Validators.required],
            end_date: ['', Validators.required]
        });

        this.userService.userData$.subscribe(userData => {
            if (userData) {
                this.role = userData.role;
            }
        });
    }

    submit(): void {
        if (this.hiringForm.invalid || this.role !== 'Responsable employabilité') {
            this.error = 'Accès refusé ou formulaire invalide';
            return;
        }

        const { start_date, end_date } = this.hiringForm.value;

        this.hiringService.predictHiring(start_date, end_date).subscribe({
            next: (res) => {
                this.predictions = res.predictions;
                this.error = null;

                this.chartData = {
                    labels: this.predictions.map(p =>
                        new Date(p.Date).toLocaleDateString()
                    ),
                    datasets: [
                        {
                            data: this.predictions.map(p => p['Borne Inf']),
                            label: 'Borne Inf.',
                            borderColor: '#999',
                            backgroundColor: 'rgba(150, 150, 150, 0.1)',
                            fill: false,
                            tension: 0.4
                        },
                        {
                            data: this.predictions.map(p => p['Borne Sup']),
                            label: 'Borne Sup.',
                            borderColor: 'red',
                            backgroundColor: 'rgba(255, 0, 0, 0.1)',
                            pointBackgroundColor: 'red',
                            pointBorderColor: 'red',
                            borderWidth: 2,
                            fill: false,
                            tension: 0.4
                        }
                    ]
                };

                this.chart?.update();
            },
            error: (err) => {
                this.error = err.error?.error || 'Erreur serveur';
                this.predictions = [];
            }
        });
    }
}
