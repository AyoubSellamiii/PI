import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HiringPredictComponent } from './hiring-predict.component';

describe('HiringPredictComponent', () => {
  let component: HiringPredictComponent;
  let fixture: ComponentFixture<HiringPredictComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HiringPredictComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(HiringPredictComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
