import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdmissionPredictComponent } from './admission-predict.component';

describe('AdmissionPredictComponent', () => {
  let component: AdmissionPredictComponent;
  let fixture: ComponentFixture<AdmissionPredictComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdmissionPredictComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdmissionPredictComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
