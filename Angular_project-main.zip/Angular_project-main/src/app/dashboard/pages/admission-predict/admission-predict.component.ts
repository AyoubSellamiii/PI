// admission-predict.component.ts
import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, ReactiveFormsModule, Validators} from '@angular/forms';
import { AdmissionService } from '../../services/admission.service';
import { MatCardModule } from '@angular/material/card';
import {MatButton} from "@angular/material/button";
import {MatFormField, MatInput} from "@angular/material/input";
import {MatOption} from "@angular/material/core";
import {MatSelect} from "@angular/material/select";
import {NgIf} from "@angular/common";
import { MatLabel } from '@angular/material/form-field';
import {RouterLink} from "@angular/router";
import {UserService} from "../../services/user.service";


@Component({
    standalone: true,
    selector: 'app-admission-predict',
    imports: [
        MatCardModule,
        ReactiveFormsModule,
        MatFormField,
        MatOption,
        MatFormField,
        MatButton,
        MatInput,
        MatSelect,
        NgIf,
        MatLabel,
        RouterLink
    ],
    templateUrl: './admission-predict.component.html'
})
export class AdmissionPredictComponent implements OnInit {
    role: string = '';
    admissionForm: FormGroup;
    result: string | null = null;
    error: string | null = null;

    constructor(private userService: UserService,private fb: FormBuilder, private admissionService: AdmissionService) {
        this.admissionForm = this.fb.group({
            moy_bac_et: [null, [Validators.required, Validators.min(0), Validators.max(20)]],
            score_final: [null, [Validators.required, Validators.min(0), Validators.max(100)]],
            Nature_diplome: ['BAC' as string, Validators.required],
            sexe: ['M' as string, Validators.required]
        });
    }

    ngOnInit(): void {
        this.userService.userData$.subscribe(userData => {
            if (userData) {
                this.role = userData.role;


            }
        });
    }

    submit() {
        if (this.admissionForm.invalid) {
            this.error = 'Formulaire invalide';
            return;
        }

        this.error = null;
        const payload = this.admissionForm.value;

        this.admissionService.predictAdmission(payload)
            .subscribe({
                next: res => this.result = res.admission_result,
                error: err => this.error = err.error?.error || 'Erreur de prédiction'
            });
    }
}
