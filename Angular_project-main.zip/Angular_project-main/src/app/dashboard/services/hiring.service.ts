// hiring.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface HiringPrediction {
    Date: string;
    Prevision: number;
    'Borne Inf': number;
    'Borne Sup': number;
}

@Injectable({
    providedIn: 'root'
})
export class HiringService {
    constructor(private http: HttpClient) {}

    predictHiring(start_date: string, end_date: string): Observable<{ status: string; predictions: HiringPrediction[] }> {
        return this.http.post<{ status: string; predictions: HiringPrediction[] }>('/api/predict_hiring', {
            start_date,
            end_date
        });
    }
}
