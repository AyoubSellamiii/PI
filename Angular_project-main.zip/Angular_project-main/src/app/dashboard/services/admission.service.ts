import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {HttpClient} from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class AdmissionService {
    constructor(private http: HttpClient) {}

    predictAdmission(payload: any): Observable<{ admission_result: string }> {
        return this.http.post<{ admission_result: string }>('/api/predict_admission', payload);
    }


}
