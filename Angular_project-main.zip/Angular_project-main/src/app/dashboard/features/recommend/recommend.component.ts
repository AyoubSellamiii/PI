import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { RecommendationService } from "../../services/recommendation.service";
import { CommonModule } from "@angular/common";
import { CustomizerSettingsService } from '../../../customizer-settings/customizer-settings.service';

// Correct Material imports
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatInputModule } from "@angular/material/input";
import { MatSelectModule } from "@angular/material/select";
import { MatCheckboxModule } from "@angular/material/checkbox";
import { MatCardModule } from "@angular/material/card";
import { MatButtonModule } from "@angular/material/button";
import { MatOptionModule } from "@angular/material/core";
import {RouterLink} from "@angular/router";
import {UserService} from "../../services/user.service";

@Component({
    standalone: true,
    selector: 'app-recommend',
    imports: [
        ReactiveFormsModule,
        CommonModule,
        MatFormFieldModule,
        MatInputModule,
        MatSelectModule,
        MatCheckboxModule,
        MatCardModule,
        MatButtonModule,
        MatOptionModule,
        RouterLink
    ],
    templateUrl: './recommend.component.html'
})
export class RecommendComponent implements OnInit {
    recommendForm!: FormGroup;
    prediction = '';
    role: string = '';

    constructor(private userService: UserService,
        private fb: FormBuilder,
        private recommendationService: RecommendationService,
        public themeService: CustomizerSettingsService,
    ) {}

    readonly bacTypes: string[] = [
        'Scientifique', 'Technique', 'Economie', 'Lettres', 'Sciences'
    ];

    readonly activiteExtras: string[] = [
        'Aucune',
        'Club Robotique',
        'Club Sportif',
        'Debat',
        'Hackathon IA'
    ];

    ngOnInit(): void {
        this.recommendForm = this.fb.group({
            Note_Maths: [null, [Validators.required, Validators.min(0), Validators.max(20)]],
            Note_Physique: [null, [Validators.required, Validators.min(0), Validators.max(20)]],
            Note_Info: [null, [Validators.required, Validators.min(0), Validators.max(20)]],
            Score_Anglais: [null, [Validators.required, Validators.min(0), Validators.max(100)]],
            Bac_Type: ['Scientifique', Validators.required],
            Activite_Extra: ['Hackathon IA', Validators.required],
            Interet_IA: [1, Validators.required]
        });

        this.userService.userData$.subscribe(userData => {
            if (userData) {
                this.role = userData.role;
            }
        });
    }





    getRecommendation() {
        if (this.recommendForm.valid) {
            this.recommendationService.predictFiliere(this.recommendForm.value).subscribe({
                next: (res: any) => this.prediction = res.recommended_filiere,
                error: err => console.error('Erreur API:', err)
            });
        } else {
            alert('Formulaire invalide.');
        }
    }
}
